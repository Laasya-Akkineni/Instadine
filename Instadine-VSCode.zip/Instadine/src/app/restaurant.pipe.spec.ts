import { RestaurantPipe } from './restaurant.pipe';

describe('RestaurantPipe', () => {
  it('create an instance', () => {
    const pipe = new RestaurantPipe();
    expect(pipe).toBeTruthy();
  });
});
