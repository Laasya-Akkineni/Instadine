import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestaurantService } from '../restaurant.service';
@Component({
  selector: 'app-restaurant-profile',
  templateUrl: './restaurant-profile.component.html',
  styleUrls: ['./restaurant-profile.component.css']
})
export class RestaurantProfileComponent implements OnInit {

restaurant:any;
  constructor() { }

  ngOnInit(): void {
    
      this.restaurant =  JSON.parse(localStorage.getItem('restaurant'));
  }
  


}
