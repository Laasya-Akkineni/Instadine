import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { NgbRatingConfig } from '@ng-bootstrap/ng-bootstrap';
declare var jQuery: any;
@Component({
  selector: 'app-orders-customer',
  templateUrl: './orders-customer.component.html',
  styleUrls: ['./orders-customer.component.css']
})
export class OrdersCustomerComponent implements OnInit {
customer:any;
customerId:any;
orders:any;
ordDetails:any;
rate:any;
rateReg: any;

  constructor(private service:RestaurantService) {
    this.orders={
      restaurant:{},customer:{}
    };
    this.rateReg={sum:'', count:'', average:''}
    this.rate={};
   }

  ngOnInit(): void {
    this.customer =  JSON.parse(sessionStorage.getItem('customer'));
    this.customerId = this.customer.customerId;
    this.service.getOrdersByCustomerId(this.customerId).subscribe((result: any) => { console.log(result); this.orders = result; });
  }

  onRateChange(event: number, ord) {
    console.log("The selected rate changed to", event);
    console.log(ord,"This is ord");
    //ord.customer=this.customer;
   
    this.service.updateOrder(ord).subscribe();



    this.service.getRating(ord.restaurant.restaurantId).subscribe((result:any) => { console.log(result); this.rate = result;
      console.log(this.rate)
      if(this.rate!=null){
        this.rate.sum = this.rate.sum + event;
        this.rate.count = this.rate.count + 1;
        this.rate.average = Math.round(this.rate.sum/this.rate.count);
        console.log("rate",this.rate)
        console.log(this.rate.average)
        ord.restaurant.rate = this.rate.average;
        console.log("Update rating", ord.restaurant)
        this.service.updateRestaurant(ord.restaurant).subscribe()
        this.service.updateRating(this.rate).subscribe();
        
      }
      else{
        this.rateReg.sum = event;
        this.rateReg.count = 1;
        this.rateReg.average = Math.round(this.rateReg.sum/this.rateReg.count);
        this.rateReg.restaurant = ord.restaurant;
        console.log('rateReg',this.rateReg)
        ord.restaurant.rate = this.rate.average;
        console.log(this.rate.average)
        console.log("Register rating", ord.restaurant)
        this.service.updateRestaurant(ord.restaurant).subscribe()

        this.service.registerRating(this.rateReg).subscribe()
        
      }})
    }
  func(ord){
    if(ord.rating == 0){
      return false;
    }
    else
    return true;
  }



  details(ord){
    this.service.getOrderDetailsByOrderId(ord.orderId).subscribe((result: any) => { console.log(result); this.ordDetails = result; });
    jQuery('#orderDetailsModel').modal('show');

  }
}
