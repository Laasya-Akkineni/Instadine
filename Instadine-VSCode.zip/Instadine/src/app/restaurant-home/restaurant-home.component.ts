import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RestaurantService } from '../restaurant.service';
declare var jQuery: any;

@Component({
  selector: 'app-restaurant-home',
  templateUrl: './restaurant-home.component.html',
  styleUrls: ['./restaurant-home.component.css']
})
export class RestaurantHomeComponent implements OnInit {
  restaurantId : any;
  foodList:any;
  orders:any
  restaurant:any;
  editObject:any;
  constructor(private route: ActivatedRoute, private service:RestaurantService, private router:Router) {
    this.editObject={}
   }

  ngOnInit(): void {
    this.restaurant =  JSON.parse(localStorage.getItem('restaurant'));
    this.restaurantId = this.restaurant.restaurantId

  }

  getOrdersByRestaurantId(){
    //this.orders = this.rest.orderList
    this.service.getOrdersByRestaurantId(this.restaurantId).subscribe((result: any) => { console.log(result); this.orders = result; });
    console.log(this.orders)
  }
  getTables(){this.router.navigate(['restaurantTable']);}

  getProfile(){this.router.navigate(['restaurantProfile']);}


  food(){this.router.navigate(['foodRegister']);}

  getMenu(){this.router.navigate(['restaurantMenu'])}

  addTables(){this.router.navigate(['tableRegister'])}

  getOrders(){this.router.navigate(['ordersrst'])}




}
