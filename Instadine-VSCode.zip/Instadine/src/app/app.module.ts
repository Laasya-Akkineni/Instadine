import { BrowserModule } from '@angular/platform-browser';
//import { DateRangePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgModule } from '@angular/core';
import{ FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { HeaderComponent } from './header/header.component';
import { RestaurantComponent } from './restaurant/restaurant.component';
import { RestaurantRegisterComponent } from './restaurant-register/restaurant-register.component';
import { CustomerRegisterComponent } from './customer-register/customer-register.component';
import { RouterModule, Routes} from '@angular/router'
import { from } from 'rxjs';
import { RestaurantLoginComponent } from './restaurant-login/restaurant-login.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { FirstpageComponent } from './firstpage/firstpage.component';
import { RestaurantHomeComponent } from './restaurant-home/restaurant-home.component';
import { ActivatedRoute } from '@angular/router';
import { RestaurantOrdersComponent } from './restaurant-orders/restaurant-orders.component';
import { TableComponentComponent } from './table-component/table-component.component';
import { RestaurantProfileComponent } from './restaurant-profile/restaurant-profile.component';
import { FoodRegisterComponent } from './food-register/food-register.component';
import { ToastrModule} from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { TableBookComponent } from './table-book/table-book.component';
import { TakeawayComponent } from './takeaway/takeaway.component';
import { DisplayFoodComponent } from './display-food/display-food.component';
import { DatefilterPipe } from './datefilter.pipe';
import { FinalComponent } from './final/final.component';
import { PaymentComponent } from './payment/payment.component';
import { RestaurantMenuComponent } from './restaurant-menu/restaurant-menu.component';
import { TableRegisterComponent } from './table-register/table-register.component';
import { CartComponent } from './cart/cart.component';
import { TotalPricePipe } from './total-price.pipe';
import { OrdersCustomerComponent } from './orders-customer/orders-customer.component';
import { OrdersRestaurantComponent } from './orders-restaurant/orders-restaurant.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { FoodPipe } from './food.pipe';
import { RestaurantPipe } from './restaurant.pipe';
import { ViewMenuComponent } from './view-menu/view-menu.component';
import { GoogleComponent } from './google/google.component';
import { AdminComponent } from './admin/admin.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


//import { MatDatepickerModule } from '@angular/';
//import { MatMomentDateModule } from '@angular/material-moment-adapter';


const appRoot: Routes =[{path:'restaurantRegister', component:RestaurantRegisterComponent},
  {path:'', component: FirstpageComponent  },
  {path:'test', component:RestaurantComponent},
  {path:'restaurantLogin', component: RestaurantLoginComponent},
  {path:'adminLogin', component: AdminLoginComponent},
  {path:'customerLogin', component:CustomerLoginComponent},
  {path:'customerRegister', component:CustomerRegisterComponent},
  {path:'restaurantComponent', component:RestaurantComponent},
  { path: 'restaurantHome', component: RestaurantHomeComponent },
  { path: 'restaurantOrders/:restaurantId', component: RestaurantHomeComponent },
  {path:'restaurantTable', component:TableComponentComponent},
  {path:'restaurantProfile', component:RestaurantProfileComponent },
  {path:'foodRegister/:restaurantId', component:FoodRegisterComponent},
  {path:'tableBook',component:TableBookComponent},
  {path:'displayfood', component:DisplayFoodComponent},
  {path:'final', component:FinalComponent},
  {path:'customerHome',component:CustomerHomeComponent},
  {path:'foodRegister', component:FoodRegisterComponent},
  {path:'payment',component:PaymentComponent},
  {path:'restaurantMenu',component:RestaurantMenuComponent},
  {path:'tableRegister', component:TableRegisterComponent},
  {path:'cart', component: CartComponent}, 
  {path:'orderscust',component:OrdersCustomerComponent},
  {path:'ordersrst',component:OrdersRestaurantComponent},
  {path:'menu',component: ViewMenuComponent },
  {path:'viewProfile', component:CustomerProfileComponent},
  {path:'admin', component:AdminComponent},
  {path:'aboutus', component:AboutusComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    HeaderComponent,
    RestaurantComponent,
    RestaurantRegisterComponent,
    CustomerRegisterComponent,
    RestaurantLoginComponent,
    CustomerLoginComponent,
    FirstpageComponent,
    RestaurantHomeComponent,
    RestaurantOrdersComponent,
    TableComponentComponent,
    RestaurantProfileComponent,
    FoodRegisterComponent,
    CustomerHomeComponent,
    TableBookComponent,
    TakeawayComponent,
    DisplayFoodComponent,
    DatefilterPipe,
    FinalComponent,
    PaymentComponent,
    RestaurantMenuComponent,
    TableRegisterComponent,
    CartComponent,
    TotalPricePipe,
    OrdersCustomerComponent,
    OrdersRestaurantComponent,
    CustomerProfileComponent,
    FoodPipe,
    RestaurantPipe,
    ViewMenuComponent,
    GoogleComponent,
    AdminComponent,
    AboutusComponent
    
   // MatDatepickerModule
   // MatMomentDateModule
   // DateRangePickerModule
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoot),
    ToastrModule.forRoot(),
    BrowserAnimationsModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
