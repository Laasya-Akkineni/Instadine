import { TotalPricePipe } from './total-price.pipe';

describe('TotalPricePipe', () => {
  it('create an instance', () => {
    const pipe = new TotalPricePipe();
    expect(pipe).toBeTruthy();
  });
});
