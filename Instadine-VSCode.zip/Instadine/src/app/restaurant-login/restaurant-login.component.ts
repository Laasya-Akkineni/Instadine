import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-restaurant-login',
  templateUrl: './restaurant-login.component.html',
  styleUrls: ['./restaurant-login.component.css']
})
export class RestaurantLoginComponent implements OnInit {
  
  email:any;
  password:any;
  restaurant:any;

  constructor(private service: RestaurantService, private router:Router, private toastr:ToastrService ) { 
    
  }

  ngOnInit(): void {
  }
  async loginSubmit(loginForm:any){
    console.log(this.email)
    console.log(this.password)
    await this.service.getRestaurantByEmailPassword(this.email, this.password).then((result:any) => {console.log('Login Sucess..',result); this.restaurant = result;
      if(this.restaurant != null && this.restaurant.status != "pending"){
        this.toastr.success('Login Successfull', 'Success')
        console.log(this.restaurant.restaurantId);
        localStorage.setItem('restaurant', JSON.stringify(this.restaurant))
        this.router.navigate(['restaurantProfile']);
       }
       else{
        this.toastr.error('Invalid Credentials', 'Error')
       }});
    

  }


}
