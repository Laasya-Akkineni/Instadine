import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'food'
})
export class FoodPipe implements PipeTransform {

  transform(foodList: any, searchText: any): any {
    if(searchText == null) return foodList;

    return foodList.filter(function(food){
      return food.foodName.toLowerCase().indexOf(searchText.toLowerCase()) > -1;
    })
  }

}
