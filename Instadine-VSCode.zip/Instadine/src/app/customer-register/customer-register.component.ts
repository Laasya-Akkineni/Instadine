import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
declare var jQuery: any;
@Component({
  selector: 'app-customer-register',
  templateUrl: './customer-register.component.html',
  styleUrls: ['./customer-register.component.css']
})
export class CustomerRegisterComponent implements OnInit {
  customerDetails:any;
  constructor(private service: RestaurantService, private router:Router,private toastr:ToastrService) {
  this.customerDetails={customerId :'', fullName:'', email:'', password:'',  phone:''};
}

  ngOnInit(): void {
  }
 /* registerSubmit(registerForm:any){
    //console.log(registerForm);
    
    //this.service.registerEmp(registerForm).subscribe((result:any) => {console.log(result)});
    this.service.registerCustomer(this.customerDetails).subscribe((result:any) => {console.log(result)});
    console.log(this.customerDetails);
  }*/
  registerSubmit(registerForm: any) {
    console.log(this.customerDetails);
    console.log(jQuery('#confPass').val());
    console.log(registerForm.password);
    if (registerForm.password === jQuery('#confPass').val() && registerForm.password != '') {
      this.toastr.success('Registration Successful','Success')
      /*this.customerDetails.firstName = registerForm.firstName;
      this.customerDetails.lastName = registerForm.lastName;
      this.customerDetails.username = registerForm.username;
      this.customerDetails.gender = registerForm.gender;
      this.customerDetails.password = registerForm.password;
      this.customerDetails.phone = registerForm.phone;*/
     

      this.service.registerCustomer(this.customerDetails).subscribe((result:any) => {console.log(result)
        this.router.navigate(['customerLogin']);
        });
      }
    else if(registerForm.password != jQuery('#confPass').val() && registerForm.password != ''){
      this.toastr.error('Registration Failed','Error')
    }

   

  }
  goToLogin(){
    this.router.navigate(['customerLogin']);
  }

}
