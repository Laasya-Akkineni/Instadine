import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-final',
  templateUrl: './final.component.html',
  styleUrls: ['./final.component.css']
})
export class FinalComponent implements OnInit {
bookDetails:any;
restaurant:any;
orderType:any;
customer:any
  constructor(private service:RestaurantService, private router: Router) { }

  ngOnInit(): void {
    this.bookDetails = JSON.parse(sessionStorage.getItem('bookDetails'));
    this.restaurant = JSON.parse(sessionStorage.getItem('restaurant'));
    this.orderType = JSON.parse(sessionStorage.getItem('orderType'));
    this.customer = JSON.parse(sessionStorage.getItem('customer'));
  }
  check(){
    
    this.router.navigate(['payment'])
  }
  

}
