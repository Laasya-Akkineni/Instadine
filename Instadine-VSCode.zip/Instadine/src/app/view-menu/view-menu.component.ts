import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-view-menu',
  templateUrl: './view-menu.component.html',
  styleUrls: ['./view-menu.component.css']
})
export class ViewMenuComponent implements OnInit {
  searchText:any;
  foodlist:any;
  rst:any;
  constructor(private service:RestaurantService) { }

  ngOnInit(): void {
    this.rst =  JSON.parse(localStorage.getItem('restaurant'));
    this.service.getFoodByRestaurantId(this.rst.restaurantId).subscribe((result: any) => { console.log(result); this.foodlist = result; });
  }

}
