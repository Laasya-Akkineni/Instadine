import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery:any;
@Component({
  selector: 'app-firstpage',
  templateUrl: './firstpage.component.html',
  styleUrls: ['./firstpage.component.css']
})
export class FirstpageComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  getCustomerLogin(){
    this.router.navigate(['customerLogin']);
  }
  getCustomerRegister(){
    this.router.navigate(['customerRegister']);
  }
  restaurant(){
    jQuery('#restaurantModel').modal('show');
  }
  getRestaurantLogin(){
    this.router.navigate(['restaurantLogin']);
  }
  getRestaurantRegister(){
    this.router.navigate(['restaurantRegister']);
  }
  


}
