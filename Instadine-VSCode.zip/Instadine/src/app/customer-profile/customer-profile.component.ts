import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {
customer:any;
  constructor() { }

  ngOnInit(): void {
    this.customer =  JSON.parse(sessionStorage.getItem('customer'));
  }

}
