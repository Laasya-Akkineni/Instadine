import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-food-register',
  templateUrl: './food-register.component.html',
  styleUrls: ['./food-register.component.css']
})
export class FoodRegisterComponent implements OnInit {
  imageUrl:string;
  fileToUpload: File=null;
  reader: FileReader;
food:any;
restaurant:any;
  constructor(private service:RestaurantService) {
    this.imageUrl='/assets/img/default-image.png';
    
   }
  ngOnInit(): void {
    this.restaurant =  JSON.parse(localStorage.getItem('restaurant'));
    console.log(this.restaurant)
    console.log(this.restaurant.restaurantId)
  }
  handFileInput(file:FileList){
    this.fileToUpload=file.item(0);

  //Show Image Preview
  this.reader=new FileReader();
  this.reader.readAsDataURL(this.fileToUpload);
  this.reader.onload=(event:any)=>{
    this.imageUrl=event.target.result;};
  }
  

 
 
OnSubmit(imageForm:any){
  console.log(imageForm)
   this.service.postFile(imageForm,this.fileToUpload,this.restaurant).subscribe(data => {
     console.log('done'+this.restaurant);
     this.imageUrl='/assets/images/food1.jpg';
   
   });
 }



}
