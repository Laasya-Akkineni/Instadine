import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
declare var jQuery: any;
@Component({
  selector: 'app-orders-restaurant',
  templateUrl: './orders-restaurant.component.html',
  styleUrls: ['./orders-restaurant.component.css']
})
export class OrdersRestaurantComponent implements OnInit {
restaurant:any;
restaurantId:any;
orders:[];
order:any
ordDetails:any;
  constructor(private service:RestaurantService) { 
    this.order={orderType:''};
  }

  ngOnInit(): void {
    this.restaurant =  JSON.parse(localStorage.getItem('restaurant'));
    this.restaurantId = this.restaurant.restaurantId;
    this.service.getOrdersByRestaurantId(this.restaurantId).subscribe((result: any) => { console.log(result); this.orders = result; });
    console.log(this.orders);
  }
  details(ord){
    this.order = ord;
    this.service.getOrderDetailsByOrderId(ord.orderId).subscribe((result: any) => { console.log(result); this.ordDetails = result; });
    jQuery('#orderDetailsModel').modal('show');

  }
  takeaway(){
    return this.order.orderType == "Takeaway"
  }
  bookTable(){
   return this.order.orderType =="Table Reservation"
  }
}
