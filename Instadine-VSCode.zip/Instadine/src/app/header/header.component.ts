import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
cartItems=[]
  constructor(private service:RestaurantService, private router:Router) {
    this.cartItems=this.service.displayCartItems;
  }

  ngOnInit(): void {

  }
  goToCart(){this.router.navigate(['cart'])}
  goToOrders(){this.router.navigate(['orderscust'])}
  goToRest(){this.router.navigate(['customerHome'])}
  viewProfile(){this.router.navigate(['viewProfile'])}

}
