import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
  credentials:any

  constructor(private router:Router) { 
    this.credentials= {loginId : '', password:''};
  }

  ngOnInit(): void {
  }
  //userForm(): void{
    //alert("Login credentials");
    //console.log(this.credentials);
  //}
  loginSubmit(loginForm:any):void{
    if(loginForm.loginId ==='admin' && loginForm.password === 'admin'){
    //  this.empService.setUserLoggedIn();
      this.router.navigate(['admin']);
     }
     else{
       alert('Invalid credentials......');
     }
     console.log(loginForm);

  }

}
