import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-restaurant-orders',
  templateUrl: './restaurant-orders.component.html',
  styleUrls: ['./restaurant-orders.component.css']
})
export class RestaurantOrdersComponent implements OnInit {
restaurantId:any;
orders:any
  constructor(private route:ActivatedRoute, private service:RestaurantService) {

   }

  ngOnInit(): void {
    let id = this.route.snapshot.params['restaurantId'];
    this.restaurantId=id;
  }
  getAllOrders(){
    
  }
  getPendingOrders(){

  }
  getConfirmedOrders(){

  }

}
