import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../restaurant.service';
import { ActivatedRoute } from '@angular/router';
declare var jQuery: any;
@Component({
  selector: 'app-table-component',
  templateUrl: './table-component.component.html',
  styleUrls: ['./table-component.component.css']
})
export class TableComponentComponent implements OnInit {
tables:any;
rst:any;
restaurantId:any;
editObject:any
  constructor(private service:RestaurantService) {
    this.editObject={
        restaurant:{}
      };
   }

    ngOnInit(): void  {
    this.rst =  JSON.parse(localStorage.getItem('restaurant'));

     this.service.getTablesByRestaurantId(this.rst.restaurantId).then((result: any) => { console.log(result); this.tables = result;});
    }

  delete(table: any): any {
    this.service.deleteTable(table).subscribe((result: any) => {
      console.log(table);
      const i = this.tables.findIndex((element) => {
        return element.tableId === table.tableId;
      });
      this.tables.splice(i, 1);
    });
  }

  showEditPopup(table: any) {
    this.editObject = table;
    jQuery('#tableModel').modal('show');
  }
  updateTable() {
    this.editObject.restaurant =this.rst;
    this.service.updateTable(this.editObject).subscribe();
    console.log(this.editObject);
  }



}
